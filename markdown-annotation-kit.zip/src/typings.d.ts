// Type declarations for third-party modules

/// <reference types="@testing-library/jest-dom" />
