import {
  require_react_dom
} from "./chunk-7IK24P44.js";
import "./chunk-SSG3GYI6.js";
import "./chunk-DC5AMYBS.js";
export default require_react_dom();
//# sourceMappingURL=react-dom.js.map
