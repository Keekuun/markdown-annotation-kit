import {
  require_jsx_runtime
} from "./chunk-DIPKL5H7.js";
import "./chunk-SSG3GYI6.js";
import "./chunk-DC5AMYBS.js";
export default require_jsx_runtime();
//# sourceMappingURL=react_jsx-runtime.js.map
