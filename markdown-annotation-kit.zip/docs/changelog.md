# 更新日志

所有重要的变更都会记录在此文件中。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)，
版本号遵循 [Semantic Versioning](https://semver.org/lang/zh-CN/)。

---

查看完整的更新日志：[CHANGELOG.md](https://github.com/Keekuun/markdown-annotation-kit/blob/main/CHANGELOG.md)

